﻿using UnityEngine;

namespace GameBrains.Percepts
{
    public class PositionPercept : Percept
    {
        public Vector3? Position { get; set; }
    }
}