using UnityEngine;

namespace GameBrains.PerformanceMeasures
{
    public class PerformanceCriteria : MonoBehaviour
    {
        // How much do we care about this criteria?
        public float weightPercentage;

        // TODO: What do we measure? Are there multiple criteria? How are they blended?
    }
}