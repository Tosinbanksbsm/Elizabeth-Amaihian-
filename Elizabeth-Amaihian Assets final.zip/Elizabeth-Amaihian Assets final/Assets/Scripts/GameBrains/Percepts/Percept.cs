﻿namespace GameBrains.Percepts
{
    public class Percept
    {
    }
}